# IMDB Sentiment Movie Review Analysis (Classical vs Deep Learning)

This repository contains a complete **end-to-end sentiment analysis project** built on the Kaggle **IMDB Dataset.csv**.
The goal is to classify movie reviews as **positive** or **negative**, and to compare a strong traditional baseline
(**TF-IDF + Logistic Regression**) against neural network approaches (**CNN** and **BiLSTM**) implemented in Keras/TensorFlow.

The project is designed to be:
- **Colab-ready** (commands are tested as `python -m src.<module>` style)
- **Reproducible** (each run saves a timestamped folder with `metrics.json`)
- **Traceable and report-friendly** (run comparison summaries, plots, and explainability tools)
- **Safe for GitHub** (dataset, models, and outputs are excluded via `.gitignore`)

---

## Project Objectives

1. Build a clean sentiment classification pipeline using IMDB movie reviews.
2. Establish a baseline using classical NLP techniques (TF-IDF features + Logistic Regression).
3. Train deep learning models (CNN and BiLSTM) and compare them to the baseline using standard metrics.
4. Track experiments in a structured way by saving:
   - model artifacts
   - evaluation metrics and confusion matrices
   - training history (for deep models)
5. Provide extra utilities:
   - dataset sanity checks (distribution, duplicates, outliers)
   - run comparison tables (`summary.json` and `summary.csv`)
   - plots for dataset and performance comparison
   - prediction scripts for both classical and deep models
   - explainability (feature contribution analysis) for TF-IDF Logistic Regression

---

## Dataset

The project uses the Kaggle dataset file **IMDB Dataset.csv** which contains:
- `review`: text of the movie review
- `sentiment`: label (`positive` or `negative`)

```
/content/imdb_sentiment/data/IMDB Dataset.csv
```

## Environment and Dependencies

This project is built for **Python 3** and runs easily in **Google Colab**.

