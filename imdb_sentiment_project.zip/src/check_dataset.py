"""Dataset sanity checks for IMDB Kaggle CSV.

Run:
python -m src.check_dataset --csv "data/IMDB Dataset.csv"
"""
from __future__ import annotations

import argparse
import re
from collections import Counter
from pathlib import Path

import pandas as pd

from src.data import load_imdb_csv


POS_WORDS = {
    "good","great","excellent","amazing","awesome","love","loved","like","liked",
    "best","wonderful","brilliant","fantastic","enjoy","enjoyed","perfect",
    "superb","favorite","fun","masterpiece","beautiful","positive"
}
NEG_WORDS = {
    "bad","terrible","awful","worst","boring","hate","hated","dislike","poor",
    "waste","stupid","dull","annoying","horrible","disappoint","disappointed",
    "mess","garbage","ridiculous","negative"
}


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z']+", str(text).lower())


def polarity_score(text: str) -> int:
    toks = tokenize(text)
    c = Counter(toks)
    pos = sum(c[w] for w in POS_WORDS if w in c)
    neg = sum(c[w] for w in NEG_WORDS if w in c)
    return pos - neg


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True)
    p.add_argument("--samples", type=int, default=3)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--top_suspicious", type=int, default=15)
    p.add_argument("--export_csv", default=None, help="Optional: write suspicious rows to this path")
    args = p.parse_args()

    df = load_imdb_csv(args.csv)
    print("Rows:", len(df))
    print("Label distribution:", df["label"].value_counts().to_dict())

    # Length stats
    lengths = df["text"].astype(str).map(lambda s: len(s.split()))
    print("\n=== Length stats (words) ===")
    print("min:", int(lengths.min()), "median:", float(lengths.median()), "mean:", float(lengths.mean()), "max:", int(lengths.max()))

    # Duplicate detection
    dup_count = int(df["text"].duplicated().sum())
    print("\n=== Duplicates ===")
    print("Exact duplicate texts:", dup_count)

    # Show a few examples
    print("\n=== Sample reviews ===")
    for label in [0, 1]:
        subset = df[df["label"] == label].sample(n=min(args.samples, (df["label"] == label).sum()), random_state=args.seed + label)
        name = "POSITIVE" if label == 1 else "NEGATIVE"
        print(f"\n--- {name} samples ({len(subset)}) ---")
        for idx, row in subset.iterrows():
            s = polarity_score(row["text"])
            snippet = row["text"][:400].replace("\n", " ")
            print(f"idx={idx} lex_score={s} :: {snippet}{'...' if len(row['text'])>400 else ''}")

    # Heuristic suspicious rows: label vs lexicon score disagreement
    scores = df["text"].map(polarity_score)
    signed = scores.copy()
    signed[df["label"] == 0] = -signed[df["label"] == 0]
    suspicious = signed.sort_values(ascending=True).head(args.top_suspicious)

    print(f"\n=== Top {args.top_suspicious} suspicious rows (heuristic) ===")
    rows = []
    for idx in suspicious.index:
        label = int(df.loc[idx, "label"])
        raw_score = int(scores.loc[idx])
        t = df.loc[idx, "text"]
        print(f"\nidx={idx} label={'pos' if label==1 else 'neg'} lex_score={raw_score}")
        print(t[:500].replace("\n", " ") + ("..." if len(t) > 500 else ""))
        rows.append({"idx": int(idx), "label": label, "lex_score": raw_score, "text": t})

    if args.export_csv:
        out = Path(args.export_csv)
        out.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(rows).to_csv(out, index=False)
        print("\nWrote suspicious rows CSV:", out)


if __name__ == "__main__":
    main()
