"""IMDB sentiment project package."""
